Ficha de Avaliação Final: Enunciado Web Scraping

```bash
pip install -r requirements.txt
```


ou 

```bash
pip install beautifulsoup4 html5lib requests scrapy selenium
```


* Atividade 1 - bautifulsoupDemo
* Atividade 2 - scrappyDemo
* Atividade 3 - scrappyDemo
* Atividade 4 - Customização 
  * listagem de curso em eisnt.com (ex04.py & FlaskApp)
