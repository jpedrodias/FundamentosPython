'''
Avaliação Intermédia 1 - Parte 3 - Exercício 6 - CRUD System com SQLite & Flask

* pip install flask

* cd flaskapp

* python app.py

* abrir http://localhost:5000/ no browser


'''

